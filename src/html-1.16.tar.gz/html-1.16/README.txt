For documentation please "pydoc html". The same documentation is available
at http://pypi.python.org/pypi/html

To run its tests use "python -m html".

To install under Python 2:

% python setup.py install

To install under Python 3:

% python3 setup.py build install
